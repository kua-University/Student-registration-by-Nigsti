from pathlib import Path
import os

# Build paths inside the project like this: BASE_DIR / 'subdir'
BASE_DIR = Path(__file__).resolve().parent.parent

# Add this line to fix the warning
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'students',
]

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'student_reg',
        'USER': 'root',
        'PASSWORD': '',  # Replace with the password you set during MySQL installation
        'HOST': 'localhost',
        'PORT': '3306',
        'OPTIONS': {
            'init_command': "SET sql_mode='STRICT_TRANS_TABLES'"
        }
    }
}

# Ensure 'django.template.backends.django.DjangoTemplates' is configured
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],  # Add your template directories here
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

# Ensure the required middleware is included
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',  # Ensure this is before AuthenticationMiddleware
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

LOGIN_REDIRECT_URL = 'home'
LOGIN_URL = 'login'
LOGOUT_REDIRECT_URL = 'login'

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

# If DEBUG is False, you must set allowed hosts
ALLOWED_HOSTS = ['localhost', '127.0.0.1']

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'django-insecure-your-secret-key-here'

# Static files (CSS, JavaScript, Images)
STATIC_URL = 'static/'

# Additional locations of static files
STATICFILES_DIRS = [
    # BASE_DIR / "static",  # Uncomment this if you have a static folder in your project root
]

# Directory where Django will collect all static files
STATIC_ROOT = BASE_DIR / 'staticfiles'

# Root URL Configuration
ROOT_URLCONF = 'student_registration.urls'

# Chapa Payment Configuration
CHAPA_API_KEY = 'CHASECK_TEST-jlm8m3ZJiu9pNuvWiougRYAJ0moD3mqt'
CHAPA_API_URL = 'https://api.chapa.co/v1/transaction/initialize'
PAYMENT_AMOUNT = '1000'  # Amount in ETB
PAYMENT_CURRENCY = 'ETB' 